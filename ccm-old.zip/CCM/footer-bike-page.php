<footer class="footer-page-components text-center">
	<div class="container">
		<div class="info-text">
			<span>All Content © CCM Motorcycles | Registered In England And Wales: 05949003 | VAT No: 847 11 56 24</span>
		</div>
		<div class="links">
			<a href="/privacy-policy/" target="_blank">Privacy Policy &amp; Cookies</a>

		</div>
		<div class="logo text-center">
			<a class="logo-page-components" href="http://www.ccm-motorcycles.com"><img src="https://www.ccm-motorcycles.com/wp-content/uploads/2018/02/logo.png" class="img-responsive"></a>
		</div>
	</div>
	
</footer>
<div class="whats-app"> <a href="https://wa.me/7791962112"> <img src="https://www.ccm-motorcycles.com/wp-content/uploads/2020/11/WhatsApp_icon.png"> </a> </div>
<?php wp_footer();?>
   <!--[if lte IE 9]>
		<script src="javascripts/non-responsive.js"></script>
	<![endif]-->


	</body>
	</html>
