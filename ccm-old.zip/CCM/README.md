naked-wordpress
===============

A well-commented blank Wordpress theme.
