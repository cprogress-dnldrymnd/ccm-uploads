jQuery(document).ready(function(){
    jQuery('#user_login').attr('placeholder', 'Username or Email Address');
    jQuery('#user_pass').attr('placeholder', 'Password');
   
});